# library
import numpy as np
import scipy as sp
import scipy.stats
import matplotlib.pyplot as plt


###########################################################
# Statistical Test
###########################################################

def myvar(x):
    m = x.mean()
    return( sum((x-m)**2)/(len(x)-1) )

x = np.array([-0.31,-0.67,-0.61,-2.07,-1.31])
m = x.mean()
s = np.sqrt(x.var(ddof=1))
n = len(x)
se = s/np.sqrt(n)

# Assuming H0 ~ Normal
SN = sp.stats.norm()
p = np.array([0.99,0.95,0.90])
k = SN.ppf(1-(1-p)/2)
ci_norm = np.concatenate((p,m-k*se,m+k*se)).reshape((3,3)).T
z = (m-0)/se
pv_norm = 2*(1-SN.cdf(abs(z)))


# Assuming H0 ~ T
ST = sp.stats.t(n-1)
p = np.array([0.99,0.95,0.90])
k = ST.ppf(1-(1-p)/2)
ci_t = np.concatenate((p,m-k*se,m+k*se)).reshape((3,3)).T
t = (m-0)/se
pv_t = 2*(1-ST.cdf(abs(t)))

# using python function
sp.stats.ttest_1samp(x,0)



###########################################################
# Practices
###########################################################

NLIST = [5,10,20,30,50]
CI = np.zeros((len(NLIST),3))
CI[:,0] = NLIST
for i in range(len(NLIST)):
    np.random.seed(2)
    x = np.random.randn(NLIST[i])+0.5
    # fill by yourself
    CI[i,1] = 0 # lower ci
    CI[i,2] = 0 # upper ci
    
    









































# PLEASE DO NOT GO DOWN BEFORE YOU TRY BY YOURSELF

###########################################################
# Practice Reference Code
###########################################################


# practice
NLIST = [5,10,20,30,50]
CI = np.zeros((len(NLIST),3))
CI[:,0] = NLIST
for i in range(len(NLIST)):
    np.random.seed(2)
    x = np.random.randn(NLIST[i])+0.5   
    m = x.mean()
    s = np.sqrt(myvar(x))
    n = len(x)
    se = s/np.sqrt(n)
    ST = sp.stats.t(n-1)
    k = ST.ppf(1-(1-0.95)/2)   
    CI[i,1] = m-k*se
    CI[i,2] = m+k*se
    
    

