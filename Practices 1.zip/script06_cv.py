# libraries
import numpy as np
import scipy as sp
import pandas as pd
import matplotlib.pyplot as plt
%matplotlib inline

# read data from file
df = pd.read_csv('data01_iris.csv')
X = df.iloc[:,:-1]
Y = df['Species']

# separating train & test sets
from sklearn.model_selection import train_test_split
xtrain, xtest, ytrain, ytest = train_test_split(X,Y,test_size=0.4,random_state=0) 

# K-fold CV
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import cross_val_score
f = LogisticRegression()
f.fit(xtrain,ytrain)
f.score(xtrain,ytrain)
f.score(xtest,ytest)
s = cross_val_score(f,xtrain,ytrain,cv=3)
s.mean()


###########################################################
# Practice
###########################################################

# Practice 1
# - ‘data06_iris2.cvs’를 읽어, Logistic Regression과 
#   LDA, QDA에 대하여 각각 교차검증 스코어를 구하시오. 
# - 어느 모델이 가장 좋은 스코어를 갖는지 확인하시오.

# Practice 2
# - ‘data05_boston.cvs’를 읽어, train_test_split을 이용하여 
#   train과 test 셋으로 나누시오. (random_state=0, test_size=0.4)
# - 교차검증을 통해 변수를 선택하고, 그 변수로 이루어진 모델에 대하여 test 셋에서 성능을 측정하시오.














































# PLEASE DO NOT GO DOWN BEFORE YOU TRY BY YOURSELF

###########################################################
# Practice Reference Code
###########################################################



